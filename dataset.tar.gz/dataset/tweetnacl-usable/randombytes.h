void randombytes(unsigned char * ptr,unsigned long long length);
