Patches performed to improve the analysis with Eva
==================================================

- [unsound] Recursive call commented out in `editorUpdateSyntax`
